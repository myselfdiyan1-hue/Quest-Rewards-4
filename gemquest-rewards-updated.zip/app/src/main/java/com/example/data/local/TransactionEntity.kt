package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val type: String, // "COINS" or "GEMS"
    val amount: Int,
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)
