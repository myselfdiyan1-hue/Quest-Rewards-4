package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_balance")
data class UserBalanceEntity(
    @PrimaryKey val id: Int = 1,
    val coins: Int = 0,
    val gems: Int = 0
)
