package com.example.ui.home

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Games
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.firebase.FirebaseManager
import com.example.data.firebase.RewardTask
import com.example.data.model.TestConfig
import com.example.data.repository.RewardRepository
import com.example.ui.components.CyanGemIcon
import com.example.ui.components.GameObjectGraphic
import com.example.ui.components.GemBalanceBadge
import com.example.ui.components.GoldCoinIcon
import com.example.ui.components.TreasureChestIllustration
import com.example.ui.components.bounceClick
import com.example.ui.components.subtleBreathing
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CardWhite
import com.example.ui.theme.CoinGold
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.GemCyan
import com.example.ui.theme.HeaderBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.OrangeAccent
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.SecondaryBlue
import com.example.ui.theme.SecondaryText
import com.example.ui.theme.SuccessGreen
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    firebaseManager: FirebaseManager,
    rewardRepository: RewardRepository,
    onNavigateToWallet: () -> Unit,
    onNavigateToImageFinder: () -> Unit,
    onNavigateToSuperOffer: () -> Unit,
    onNavigateToMoreTasks: () -> Unit,
    onNavigateToTaskHistory: () -> Unit,
    onNavigateToProfile: () -> Unit = {},
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager: ClipboardManager = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()

    val balance by viewModel.balance.collectAsStateWithLifecycle()
    val activeSession by viewModel.activeOfferSession.collectAsStateWithLifecycle()
    val isUnlocking by viewModel.isUnlocking.collectAsStateWithLifecycle()
    val appConfig by viewModel.appConfig.collectAsStateWithLifecycle()
    val userProfile by firebaseManager.userProfile.collectAsStateWithLifecycle()
    val liveTasks by firebaseManager.liveTasks.collectAsStateWithLifecycle()

    var showProfileMenu by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showReferDialog by remember { mutableStateOf(false) }
    var showAccountDialog by remember { mutableStateOf(false) }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    LaunchedEffect(Unit) {
        viewModel.eventFlow.collect { event ->
            when (event) {
                is HomeUiEvent.NavigateToSuperOffer -> {
                    onNavigateToSuperOffer()
                }
                is HomeUiEvent.ShowMessage -> {
                    Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MainBackground)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
            .testTag("home_screen")
    ) {
        // TOP HEADER: Gol Shap Profile Icon next to Quest Rewards + Gem Badge
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = HeaderBackground,
            shadowElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left: Three-Line Menu Icon + "Quest Rewards" title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Three-line menu button (opens Profile & Menu bottom sheet)
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFEEF2FF))
                            .border(1.dp, Color(0xFFDBEAFE), RoundedCornerShape(12.dp))
                            .bounceClick {
                                showProfileMenu = true
                            }
                            .testTag("user_profile_avatar_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = androidx.compose.material.icons.Icons.Filled.Menu,
                            contentDescription = "Open Profile & Menu",
                            tint = PrimaryBlue,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showProfileMenu = true }
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Quest Rewards",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryText
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(SuccessGreen)
                            )
                            Text(
                                text = "Official Live Rewards",
                                fontSize = 11.sp,
                                color = SuccessGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Right: Gem Balance Badge
                GemBalanceBadge(
                    gems = balance.gems,
                    modifier = Modifier.testTag("header_gem_badge")
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Column(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Balance Card (Animated Bounce Clickable)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("balance_card")
                    .bounceClick { onNavigateToWallet() },
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF1E3A8A),
                                    Color(0xFF2563EB),
                                    Color(0xFF7C3AED),
                                    Color(0xFFEA580C),
                                    Color(0xFFF97316)
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.20f))
                                    .padding(6.dp)
                            ) {
                                GoldCoinIcon(size = 40.dp)
                            }
                            Column {
                                Text(
                                    text = "Available Coins",
                                    fontSize = 13.sp,
                                    color = Color.White.copy(alpha = 0.90f),
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${balance.coins}",
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            }
                        }

                        Button(
                            onClick = onNavigateToWallet,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = Color(0xFF1E3A8A)
                            ),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp),
                            modifier = Modifier.testTag("go_to_wallet_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "Wallet",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    tint = Color(0xFF1E3A8A),
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 2. TWO-COLUMN ANIMATED CARDS: SUPER OFFER & IMAGE FINDER
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Max),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val reqGems = appConfig.superOfferUnlockGems
                val reqCoins = appConfig.superOfferUnlockCoins
                val hasEnoughGems = (balance.gems >= reqGems) && (balance.coins >= reqCoins)
                val hasActiveSession = activeSession != null

                // CARD 1: SUPER OFFER (Blue gradient + subtle breathing animation)
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .subtleBreathing(enabled = true)
                        .bounceClick { onNavigateToSuperOffer() }
                        .testTag("super_offer_card"),
                    shape = RoundedCornerShape(22.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 5.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFF2563EB),
                                        Color(0xFF1D4ED8),
                                        Color(0xFF1E40AF)
                                    )
                                )
                            )
                            .padding(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                // Top Tag
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color.White.copy(alpha = 0.22f))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = "FEATURED",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color.White
                                        )
                                    }

                                    if (hasActiveSession) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(SuccessGreen)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "ACTIVE",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Black,
                                                color = Color.White
                                            )
                                        }
                                    } else if (!hasEnoughGems) {
                                        Icon(
                                            imageVector = Icons.Filled.Lock,
                                            contentDescription = "Locked",
                                            tint = Color.White.copy(alpha = 0.8f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Box(
                                    modifier = Modifier.fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    TreasureChestIllustration(size = 46.dp)
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = "SUPER OFFER",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    maxLines = 1
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    GoldCoinIcon(size = 15.dp)
                                    Text(
                                        text = "+${TestConfig.SUPER_OFFER_COIN_REWARD} Coins",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFFDE047)
                                    )
                                }

                                Spacer(modifier = Modifier.height(2.dp))

                                val unlockText = when {
                                    hasActiveSession -> "Session in progress"
                                    reqCoins > 0 && reqGems > 0 -> "$reqGems Gems + $reqCoins Coins"
                                    reqCoins > 0 -> "$reqCoins Coins to unlock"
                                    else -> "$reqGems Gems to unlock"
                                }
                                Text(
                                    text = unlockText,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White.copy(alpha = 0.85f),
                                    maxLines = 1
                                )
                            }

                            Column {
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = onNavigateToSuperOffer,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(38.dp)
                                        .testTag("super_offer_action_button"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.White,
                                        contentColor = Color(0xFF2563EB)
                                    ),
                                    contentPadding = PaddingValues(horizontal = 6.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = if (hasActiveSession) "Continue" else "Open Offer",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // CARD 2: IMAGE FINDER (Orange gradient + subtle breathing animation)
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .subtleBreathing(enabled = true)
                        .bounceClick { onNavigateToImageFinder() }
                        .testTag("image_finder_card"),
                    shape = RoundedCornerShape(22.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 5.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFFF97316),
                                        Color(0xFFEA580C),
                                        Color(0xFFC2410C)
                                    )
                                )
                            )
                            .padding(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                // Top Tag
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color.White.copy(alpha = 0.22f))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = "PLAY & EARN",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color.White
                                        )
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(CircleShape)
                                            .background(Color.White.copy(alpha = 0.25f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "GEMS",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color.White
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Box(
                                    modifier = Modifier.fillMaxWidth(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(Color.White.copy(alpha = 0.20f))
                                            .padding(6.dp)
                                    ) {
                                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                                GameObjectGraphic(name = "banana", size = 18.dp)
                                                GameObjectGraphic(name = "apple", size = 18.dp)
                                            }
                                            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                                GameObjectGraphic(name = "car", size = 18.dp)
                                                GameObjectGraphic(name = "cat", size = 18.dp)
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = "IMAGE FINDER",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    maxLines = 1
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    CyanGemIcon(size = 15.dp)
                                    Text(
                                        text = "+${TestConfig.GEM_REWARD_PER_ROUND} Gem / Win",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFBAE6FD)
                                    )
                                }

                                Spacer(modifier = Modifier.height(2.dp))

                                Text(
                                    text = "Earn Gems to Unlock",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White.copy(alpha = 0.85f),
                                    maxLines = 1
                                )
                            }

                            Column {
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = onNavigateToImageFinder,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(38.dp)
                                        .testTag("gems_collect_button"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.White,
                                        contentColor = Color(0xFFEA580C)
                                    ),
                                    contentPadding = PaddingValues(horizontal = 6.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = "Play Game",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 3. MORE TASKS SECTION (LIVE DYNAMIC TASKS FROM ADMIN PANEL / FIRESTORE)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.LocalFireDepartment,
                            contentDescription = "Tasks",
                            tint = OrangeAccent,
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = "Tasks",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryText
                        )
                    }

                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onNavigateToMoreTasks() }
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "View All",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryBlue
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "View All",
                            tint = PrimaryBlue,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                // Display pure dynamic tasks from Admin Panel (Firestore) - NO DEMO DATA
                if (liveTasks.isEmpty()) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("home_tasks_empty_card"),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = CardWhite),
                        border = BorderStroke(1.dp, BorderSubtle)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Filled.LocalFireDepartment,
                                contentDescription = null,
                                tint = Color(0xFFCBD5E1),
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No Tasks Active",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryText
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Tasks added from Admin Panel will appear here automatically.",
                                fontSize = 12.sp,
                                color = SecondaryText,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    liveTasks.filter { it.isEnabled }.take(5).forEach { task ->
                        HomeTaskCard(
                            task = task,
                            onTaskClicked = {
                                if (!task.isCompleted) {
                                    onNavigateToMoreTasks()
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // =========================================================================
    // PROFILE MENU MODAL (Opens when clicking user circular profile avatar)
    // Strictly contains: Privacy Policy, Refer and Earn, Logout, Account Connect, History
    // "baaki kuch nahi"
    // =========================================================================
    if (showProfileMenu) {
        ModalBottomSheet(
            onDismissRequest = { showProfileMenu = false },
            sheetState = sheetState,
            containerColor = Color.White,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with User Profile Summary
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                colors = listOf(
                                    PrimaryBlue,
                                    PurpleAccent,
                                    OrangeAccent,
                                    PrimaryBlue
                                )
                            )
                        )
                        .padding(3.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFEEF2FF)),
                    contentAlignment = Alignment.Center
                ) {
                    val displayName = userProfile?.displayName?.ifBlank { "User" } ?: "User"
                    val initial = displayName.trim().firstOrNull()?.uppercase() ?: "U"
                    Text(
                        text = initial,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        color = PrimaryBlue
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = userProfile?.displayName?.ifBlank { "Google User" } ?: "Google User",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryText
                )

                Text(
                    text = userProfile?.email?.ifBlank { "Signed In" } ?: "Signed In",
                    fontSize = 12.sp,
                    color = SecondaryText
                )

                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFECFDF5))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(SuccessGreen))
                        Text(
                            text = "Account Synced & Active",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF047857)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                HorizontalDivider(color = BorderSubtle)
                Spacer(modifier = Modifier.height(12.dp))

                // 0. MY PROFILE
                ProfileMenuItem(
                    icon = Icons.Filled.AccountCircle,
                    iconTint = PrimaryBlue,
                    title = "My Profile",
                    subtitle = "View account profile, coins & reward rates",
                    onClick = {
                        showProfileMenu = false
                        onNavigateToProfile()
                    }
                )

                // 1. PRIVACY POLICY
                ProfileMenuItem(
                    icon = Icons.Filled.PrivacyTip,
                    iconTint = Color(0xFF2563EB),
                    title = "Privacy Policy",
                    subtitle = "Data security & terms of service",
                    onClick = {
                        showProfileMenu = false
                        showPrivacyDialog = true
                    }
                )

                // 2. REFER AND EARN
                ProfileMenuItem(
                    icon = Icons.Filled.Share,
                    iconTint = Color(0xFFEA580C),
                    title = "Refer and Earn",
                    subtitle = "Invite friends & get bonus coins",
                    onClick = {
                        showProfileMenu = false
                        showReferDialog = true
                    }
                )

                // 3. ACCOUNT CONNECT
                ProfileMenuItem(
                    icon = Icons.Filled.AccountCircle,
                    iconTint = Color(0xFF7C3AED),
                    title = "Account Connect",
                    subtitle = "Google login & sync info",
                    onClick = {
                        showProfileMenu = false
                        showAccountDialog = true
                    }
                )

                // 4. HISTORY
                ProfileMenuItem(
                    icon = Icons.Filled.History,
                    iconTint = Color(0xFF059669),
                    title = "History",
                    subtitle = "Past tasks, rewards & withdrawals",
                    onClick = {
                        showProfileMenu = false
                        onNavigateToTaskHistory()
                    }
                )

                // 5. LOGOUT
                ProfileMenuItem(
                    icon = Icons.Filled.ExitToApp,
                    iconTint = ErrorRed,
                    title = "Logout",
                    subtitle = "Sign out from this device",
                    isDestructive = true,
                    onClick = {
                        showProfileMenu = false
                        onLogout()
                    }
                )
            }
        }
    }

    // DIALOG: Privacy Policy
    if (showPrivacyDialog) {
        Dialog(onDismissRequest = { showPrivacyDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Privacy Policy",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryText
                        )
                        IconButton(onClick = { showPrivacyDialog = false }) {
                            Icon(Icons.Filled.Close, contentDescription = "Close", tint = SecondaryText)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Last updated: October 2026\n\n" +
                                "Quest Rewards values your privacy. We are committed to protecting user personal information.\n\n" +
                                "1. Account Data:\n" +
                                "We authenticate securely using Google Sign-In. We only access your basic public profile (display name, email address, profile picture).\n\n" +
                                "2. Coin & Gem Balances:\n" +
                                "All rewards, coin transactions, and withdrawal records are stored securely in Google Cloud Firestore.\n\n" +
                                "3. Advertisements & AdMob:\n" +
                                "We serve official Google AdMob rewarded advertisements. Ads are compliant with Google Play Developer Policies.\n\n" +
                                "4. Cash Payouts:\n" +
                                "Withdrawal information (UPI ID, Paytm number, bank info) is used strictly to process payment requests and never shared with third parties.\n\n" +
                                "For inquiries, contact support at: support@questrewards.live",
                        fontSize = 13.sp,
                        color = Color(0xFF475569),
                        lineHeight = 19.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { showPrivacyDialog = false },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                    ) {
                        Text("I Understand", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }

    // DIALOG: Refer and Earn
    if (showReferDialog) {
        val referralCode = userProfile?.uid?.take(8)?.uppercase() ?: "QUEST777"
        Dialog(onDismissRequest = { showReferDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Refer and Earn",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryText
                        )
                        IconButton(onClick = { showReferDialog = false }) {
                            Icon(Icons.Filled.Close, contentDescription = "Close", tint = SecondaryText)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFEF3C7)),
                        contentAlignment = Alignment.Center
                    ) {
                        GoldCoinIcon(size = 36.dp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Earn 100 Coins for Every Friend!",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryText,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "Share your personal invite code with friends. When they sign up, both of you get bonus rewards!",
                        fontSize = 12.sp,
                        color = SecondaryText,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Code Box
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFFF1F5F9),
                        border = BorderStroke(1.dp, BorderSubtle)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("YOUR REFERRAL CODE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SecondaryText)
                                Text(referralCode, fontSize = 18.sp, fontWeight = FontWeight.Black, color = PrimaryBlue)
                            }
                            IconButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(referralCode))
                                    Toast.makeText(context, "Referral code copied!", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = "Copy", tint = PrimaryBlue)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "Join Quest Rewards and earn real money! Use my code $referralCode to get a free welcome bonus: https://questrewards.live/invite/$referralCode"
                                )
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Referral Code"))
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = OrangeAccent)
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = "Share", tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Share with Friends", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }

    // DIALOG: Account Connect
    if (showAccountDialog) {
        Dialog(onDismissRequest = { showAccountDialog = false }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(22.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Account Connect",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryText
                        )
                        IconButton(onClick = { showAccountDialog = false }) {
                            Icon(Icons.Filled.Close, contentDescription = "Close", tint = SecondaryText)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFFF8FAFC),
                        border = BorderStroke(1.dp, BorderSubtle)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Filled.CheckCircle, contentDescription = "Connected", tint = SuccessGreen, modifier = Modifier.size(20.dp))
                                Text("Connected via Google Account", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF047857))
                            }

                            HorizontalDivider(color = Color(0xFFE2E8F0))

                            Column {
                                Text("Display Name", fontSize = 11.sp, color = SecondaryText)
                                Text(userProfile?.displayName ?: "Google User", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = PrimaryText)
                            }

                            Column {
                                Text("Email", fontSize = 11.sp, color = SecondaryText)
                                Text(userProfile?.email ?: "Not available", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = PrimaryText)
                            }

                            Column {
                                Text("Account ID", fontSize = 11.sp, color = SecondaryText)
                                Text(userProfile?.uid ?: "uid_anonymous", fontSize = 12.sp, color = SecondaryText)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { showAccountDialog = false },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                    ) {
                        Text("Done", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

/**
 * Animated Card for Each Task from Admin Panel / Firestore
 */
@Composable
fun HomeTaskCard(
    task: RewardTask,
    onTaskClicked: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .bounceClick { onTaskClicked() }
            .testTag("task_card_${task.id}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        border = BorderStroke(1.dp, BorderSubtle),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                val (iconVector, iconBg, iconTint) = when (task.category.uppercase()) {
                    "INSTALL" -> Triple(Icons.Filled.ShoppingBag, Color(0xFFEFF6FF), PrimaryBlue)
                    "VIDEO" -> Triple(Icons.Filled.OndemandVideo, Color(0xFFFEF2F2), ErrorRed)
                    "SURVEY" -> Triple(Icons.Filled.Poll, Color(0xFFFAF5FF), PurpleAccent)
                    "DAILY" -> Triple(Icons.Filled.Stars, Color(0xFFFEF3C7), OrangeAccent)
                    "SOCIAL" -> Triple(Icons.Filled.Send, Color(0xFFECFDF5), SuccessGreen)
                    else -> Triple(Icons.Filled.Games, Color(0xFFF1F5F9), PrimaryBlue)
                }

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = iconVector,
                        contentDescription = task.title,
                        tint = iconTint,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryText,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = task.description,
                        fontSize = 11.sp,
                        color = SecondaryText,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Coin Reward or Completed Pill
            if (task.isCompleted) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFDCFCE7))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Done",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF15803D)
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFFEF3C7))
                        .border(1.dp, Color(0xFFFDE68A), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        GoldCoinIcon(size = 15.dp)
                        Text(
                            text = "+${task.rewardCoins}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black,
                            color = Color(0xFF92400E)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Menu Item Row for Profile Modal
 */
@Composable
fun ProfileMenuItem(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    isDestructive: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconTint.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }

            Column {
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDestructive) ErrorRed else PrimaryText
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = SecondaryText
                )
            }
        }

        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = if (isDestructive) ErrorRed else Color(0xFF94A3B8),
            modifier = Modifier.size(16.dp)
        )
    }
}
