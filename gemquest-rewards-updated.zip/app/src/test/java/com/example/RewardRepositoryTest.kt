package com.example

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.model.TestConfig
import com.example.data.repository.RewardRepository
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class RewardRepositoryTest {

    private lateinit var database: AppDatabase
    private lateinit var repository: RewardRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = RewardRepository(database.rewardDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testInitialBalanceIsZero() = runTest {
        val balance = repository.getBalanceDirect()
        assertEquals(TestConfig.INITIAL_COINS, balance.coins)
        assertEquals(TestConfig.INITIAL_GEMS, balance.gems)
    }

    @Test
    fun testAwardGameRoundGemAndPreventDuplicate() = runTest {
        val roundId = "test_round_1"
        val awarded1 = repository.awardGameRoundGem(roundId)
        assertTrue(awarded1)

        val balanceAfter1 = repository.getBalanceDirect()
        assertEquals(1, balanceAfter1.gems)

        // Try awarding for the same round again
        val awarded2 = repository.awardGameRoundGem(roundId)
        assertFalse(awarded2)

        val balanceAfter2 = repository.getBalanceDirect()
        assertEquals(1, balanceAfter2.gems)
    }

    @Test
    fun testUnlockOfferRequiresTwoGems() = runTest {
        // With 0 gems, unlock must fail
        val failResult = repository.unlockSuperOffer("pkg1,pkg2")
        assertTrue(failResult.isFailure)

        // Award 2 gems
        repository.awardGameRoundGem("round_a")
        repository.awardGameRoundGem("round_b")
        val currentGems = repository.getBalanceDirect().gems
        assertEquals(2, currentGems)

        // Now unlock succeeds
        val successResult = repository.unlockSuperOffer("pkg1,pkg2")
        assertTrue(successResult.isSuccess)

        // 2 gems must be deducted
        val balanceAfterUnlock = repository.getBalanceDirect()
        assertEquals(0, balanceAfterUnlock.gems)
    }
}
