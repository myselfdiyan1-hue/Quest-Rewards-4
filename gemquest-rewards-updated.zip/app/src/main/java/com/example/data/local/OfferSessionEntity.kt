package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "offer_sessions")
data class OfferSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val status: String = "IN_PROGRESS",
    val adWatched: Boolean = false,
    val adClicked: Boolean = false,
    val targetPackageName: String? = null,
    val targetAppName: String? = null,
    val installationObserved: Boolean = false,
    val installedPackagesSnapshot: String = "",
    val observedUsageSeconds: Long = 0,
    val requiredUsageSeconds: Long = 120,
    val currentStep: Int = 1,
    val coinsRewarded: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)
