package com.example

import android.app.Application
import com.example.ads.AdMobRewardedAdManager
import com.example.data.firebase.FirebaseManager
import com.example.data.local.AppDatabase
import com.example.data.repository.RewardRepository
import com.example.tracking.InstallationDetectionRepository
import com.example.tracking.UsageTrackingRepository

class GemQuestApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var firebaseManager: FirebaseManager
        private set

    lateinit var rewardRepository: RewardRepository
        private set

    lateinit var installationDetectionRepository: InstallationDetectionRepository
        private set

    lateinit var usageTrackingRepository: UsageTrackingRepository
        private set

    lateinit var adMobRewardedAdManager: AdMobRewardedAdManager
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        firebaseManager = FirebaseManager(this)
        rewardRepository = RewardRepository(database.rewardDao(), firebaseManager)
        installationDetectionRepository = InstallationDetectionRepository(this)
        usageTrackingRepository = UsageTrackingRepository(this)
        adMobRewardedAdManager = AdMobRewardedAdManager(this)
    }
}
