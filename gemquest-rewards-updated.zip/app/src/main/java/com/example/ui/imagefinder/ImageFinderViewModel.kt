package com.example.ui.imagefinder

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ads.AdMobRewardedAdManager
import com.example.data.local.UserBalanceEntity
import com.example.data.model.TestConfig
import com.example.data.repository.RewardRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ImageFinderState(
    val currentLevel: Int = 1,
    val targetObject: String = "Banana",
    val gridObjects: List<String> = emptyList(),
    val timerSecondsRemaining: Int = 30,
    val isPaused: Boolean = false,
    val isGameOver: Boolean = false,
    val feedbackMessage: String? = null,
    val isFeedbackSuccess: Boolean = false,
    val showGemAnimation: Boolean = false,
    val gemsEarnedInSession: Int = 0,
    // Streak tracking: user needs 3 correct finds before collecting gems
    val correctFindsCount: Int = 0, // 0, 1, 2, 3
    val isTargetStreakAchieved: Boolean = false, // true when correctFindsCount >= 3
    val isAdLoadingOrShowing: Boolean = false,
    val isAdRewardedSuccessfully: Boolean = false
)

class ImageFinderViewModel(
    private val rewardRepository: RewardRepository,
    private val adMobManager: AdMobRewardedAdManager? = null
) : ViewModel() {

    private val availableObjects = listOf(
        "Apple", "Car", "Banana", "Dog", "Football", "Cat", "Parrot", "Bicycle", "Tree"
    )

    private val _uiState = MutableStateFlow(ImageFinderState())
    val uiState: StateFlow<ImageFinderState> = _uiState.asStateFlow()

    val balance: StateFlow<UserBalanceEntity> = rewardRepository.balanceFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserBalanceEntity(id = 1, coins = TestConfig.INITIAL_COINS, gems = TestConfig.INITIAL_GEMS)
        )

    private val _toastEvent = MutableSharedFlow<String>()
    val toastEvent: SharedFlow<String> = _toastEvent.asSharedFlow()

    private var timerJob: Job? = null

    init {
        adMobManager?.loadRewardedAd()
        startNewRound(level = 1)
    }

    private fun startNewRound(level: Int) {
        val target = availableObjects.random()
        // Pick 5 distinct items different from target, then combine and shuffle
        val others = availableObjects.filter { it != target }.shuffled().take(5)
        val grid = (others + target).shuffled()

        _uiState.value = _uiState.value.copy(
            currentLevel = level,
            targetObject = target,
            gridObjects = grid,
            timerSecondsRemaining = 30,
            isPaused = false,
            isGameOver = false,
            feedbackMessage = null,
            isFeedbackSuccess = false,
            showGemAnimation = false
        )

        startTimer()
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_uiState.value.timerSecondsRemaining > 0 && !_uiState.value.isPaused && !_uiState.value.isGameOver && !_uiState.value.isTargetStreakAchieved) {
                delay(1000L)
                if (!_uiState.value.isPaused && !_uiState.value.isTargetStreakAchieved) {
                    val remaining = _uiState.value.timerSecondsRemaining - 1
                    _uiState.value = _uiState.value.copy(timerSecondsRemaining = remaining)
                    if (remaining <= 0) {
                        _uiState.value = _uiState.value.copy(
                            isGameOver = true,
                            feedbackMessage = "Time's up! Tap Try Again to keep playing.",
                            isFeedbackSuccess = false
                        )
                    }
                }
            }
        }
    }

    fun onObjectSelected(selectedName: String) {
        if (_uiState.value.isPaused || _uiState.value.isGameOver || _uiState.value.isTargetStreakAchieved) return

        val target = _uiState.value.targetObject
        if (selectedName.equals(target, ignoreCase = true)) {
            // Correct selection!
            timerJob?.cancel()
            val newStreak = _uiState.value.correctFindsCount + 1

            if (newStreak >= 3) {
                // Goal reached! 3 successful finds!
                // Ready to collect gems via AdMob test ad
                _uiState.value = _uiState.value.copy(
                    correctFindsCount = 3,
                    isTargetStreakAchieved = true,
                    feedbackMessage = "🎉 Awesome! 3/3 targets found! Tap 'Collect Gems' below to watch ad and claim your gems!",
                    isFeedbackSuccess = true
                )
                viewModelScope.launch {
                    _toastEvent.emit("Goal reached: 3/3 finds completed! Collect your Gems!")
                }
            } else {
                // Streak 1 or 2
                _uiState.value = _uiState.value.copy(
                    correctFindsCount = newStreak,
                    feedbackMessage = "Correct! ($newStreak/3 found) Keep going! 🔥",
                    isFeedbackSuccess = true
                )
                viewModelScope.launch {
                    _toastEvent.emit("Find $newStreak/3 correct! Find next item!")
                    delay(1200L)
                    val nextLevel = _uiState.value.currentLevel + 1
                    startNewRound(level = nextLevel)
                }
            }
        } else {
            // Incorrect selection
            _uiState.value = _uiState.value.copy(
                feedbackMessage = "Oops! That's a $selectedName. Find the $target!",
                isFeedbackSuccess = false
            )
        }
    }

    /**
     * User clicks "Collect Gems" after reaching 3/3 correct finds.
     * Shows Google AdMob test ad. Once completed, awards gems to balance!
     */
    fun onCollectGemsClicked(activity: Activity) {
        if (!_uiState.value.isTargetStreakAchieved) return

        if (adMobManager == null) {
            // Fallback if adMobManager not provided: award directly
            awardGemsAfterAd()
            return
        }

        _uiState.value = _uiState.value.copy(isAdLoadingOrShowing = true)

        adMobManager.showRewardedAd(
            activity = activity,
            onAdCompletedAndClicked = { _, _ ->
                // Ad completed and clicked
                awardGemsAfterAd()
            },
            onAdDismissedWithoutClick = {
                // Ad watched fully (AdMob rewarded standard)
                awardGemsAfterAd()
            },
            onAdDismissed = {
                // If dismissed or reward earned
                if (_uiState.value.isAdRewardedSuccessfully) {
                    // Already awarded
                } else {
                    _uiState.value = _uiState.value.copy(isAdLoadingOrShowing = false)
                    viewModelScope.launch {
                        _toastEvent.emit("Please watch the full ad to collect your gems!")
                    }
                }
            },
            onAdFailedToShow = { error ->
                // If ad failed to show (e.g. offline/error), award gems so user is not stuck
                viewModelScope.launch {
                    _toastEvent.emit("Ad not ready. Rewarding gems anyway!")
                }
                awardGemsAfterAd()
            }
        )
    }

    /**
     * Watch an Ad at any time during gameplay to instantly earn bonus gems.
     */
    fun onWatchAdForBonusGems(activity: Activity) {
        if (_uiState.value.isAdLoadingOrShowing) return
        _uiState.value = _uiState.value.copy(isAdLoadingOrShowing = true)

        if (adMobManager == null) {
            awardBonusGemsDirectly(1)
            return
        }

        adMobManager.showRewardedAd(
            activity = activity,
            onAdCompletedAndClicked = { amount, _ ->
                awardBonusGemsDirectly(if (amount > 0) amount else 1)
            },
            onAdDismissedWithoutClick = {
                awardBonusGemsDirectly(1)
            },
            onAdDismissed = {
                _uiState.value = _uiState.value.copy(isAdLoadingOrShowing = false)
            },
            onAdFailedToShow = { error ->
                viewModelScope.launch {
                    _toastEvent.emit("Ad note: Free gem awarded!")
                }
                awardBonusGemsDirectly(1)
            }
        )
    }

    private fun awardBonusGemsDirectly(gemsToAdd: Int) {
        viewModelScope.launch {
            val roundId = "BONUS_AD_${System.currentTimeMillis()}"
            rewardRepository.awardGameRoundGem(roundId)
            _uiState.value = _uiState.value.copy(
                isAdLoadingOrShowing = false,
                isAdRewardedSuccessfully = true,
                showGemAnimation = true,
                gemsEarnedInSession = _uiState.value.gemsEarnedInSession + gemsToAdd,
                feedbackMessage = "💎 +$gemsToAdd Gem added from Ad! Keep playing! 🎉",
                isFeedbackSuccess = true
            )
            _toastEvent.emit("🎉 +$gemsToAdd Gem added to balance!")
            delay(1800L)
            _uiState.value = _uiState.value.copy(showGemAnimation = false)
        }
    }

    private fun awardGemsAfterAd() {
        val roundId = "FINDER_3STREAK_${System.currentTimeMillis()}"
        viewModelScope.launch {
            // Award game round gem (awards 1 gem in repository, or we can award to ensure progress)
            val awarded = rewardRepository.awardGameRoundGem(roundId)

            _uiState.value = _uiState.value.copy(
                isAdLoadingOrShowing = false,
                isAdRewardedSuccessfully = true,
                showGemAnimation = true,
                gemsEarnedInSession = _uiState.value.gemsEarnedInSession + 1,
                feedbackMessage = "💎 Gems collected successfully! Great job! 🎉",
                isFeedbackSuccess = true
            )

            _toastEvent.emit("🎉 +1 Gem added to your balance!")

            delay(2000L)

            // Reset streak to 0 for next set of 3 rounds
            _uiState.value = _uiState.value.copy(
                correctFindsCount = 0,
                isTargetStreakAchieved = false,
                isAdRewardedSuccessfully = false,
                showGemAnimation = false
            )

            val currentGems = balance.value.gems
            if (currentGems >= TestConfig.SUPER_OFFER_REQUIRED_GEMS) {
                _toastEvent.emit("Awesome! You have $currentGems Gems. Super Offer is now unlocked!")
            }

            // Start new round
            startNewRound(level = _uiState.value.currentLevel + 1)
        }
    }

    fun togglePause() {
        val newPauseState = !_uiState.value.isPaused
        _uiState.value = _uiState.value.copy(isPaused = newPauseState)
        if (!newPauseState) {
            startTimer()
        }
    }

    fun restartGame() {
        _uiState.value = _uiState.value.copy(
            correctFindsCount = 0,
            isTargetStreakAchieved = false,
            isAdRewardedSuccessfully = false
        )
        startNewRound(level = 1)
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}

class ImageFinderViewModelFactory(
    private val rewardRepository: RewardRepository,
    private val adMobManager: AdMobRewardedAdManager? = null
) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ImageFinderViewModel(rewardRepository, adMobManager) as T
    }
}
