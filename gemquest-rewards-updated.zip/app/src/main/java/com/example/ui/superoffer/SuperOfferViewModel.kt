package com.example.ui.superoffer

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ads.AdMobRewardedAdManager
import com.example.ads.AdState
import com.example.data.local.OfferSessionEntity
import com.example.data.local.UserBalanceEntity
import com.example.data.model.AppInfo
import com.example.data.model.StepStatus
import com.example.data.model.TestConfig
import com.example.data.repository.RewardRepository
import com.example.tracking.InstallationDetectionRepository
import com.example.tracking.UsageTrackingRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class SuperOfferUiEvent {
    data class ShowMessage(val message: String) : SuperOfferUiEvent()
    object OfferCompletedSuccess : SuperOfferUiEvent()
    object NavigateToPermissionScreen : SuperOfferUiEvent()
}

class SuperOfferViewModel(
    private val rewardRepository: RewardRepository,
    private val installationDetectionRepository: InstallationDetectionRepository,
    private val usageTrackingRepository: UsageTrackingRepository,
    private val adMobManager: AdMobRewardedAdManager
) : ViewModel() {

    val balance: StateFlow<UserBalanceEntity> = rewardRepository.balanceFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserBalanceEntity(id = 1, coins = TestConfig.INITIAL_COINS, gems = TestConfig.INITIAL_GEMS)
        )

    val activeSession: StateFlow<OfferSessionEntity?> = rewardRepository.activeOfferSessionFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val allOfferSessions: StateFlow<List<OfferSessionEntity>> = rewardRepository.allOfferSessionsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val completedOffersCount: StateFlow<Int> = rewardRepository.allOfferSessionsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        ).run {
            // map count of completed sessions
            val countFlow = MutableStateFlow(0)
            viewModelScope.launch {
                rewardRepository.allOfferSessionsFlow.collect { list ->
                    countFlow.value = list.count { it.status == "COMPLETED" }
                }
            }
            countFlow.asStateFlow()
        }

    val adState: StateFlow<AdState> = adMobManager.adState
    val appConfig: StateFlow<com.example.data.firebase.AppConfig> = (rewardRepository.firebaseManager?.appConfig
        ?: MutableStateFlow(com.example.data.firebase.AppConfig()))
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = com.example.data.firebase.AppConfig()
        )

    private val _eventFlow = MutableSharedFlow<SuperOfferUiEvent>()
    val eventFlow: SharedFlow<SuperOfferUiEvent> = _eventFlow.asSharedFlow()

    private val _showPermissionDialog = MutableStateFlow(false)
    val showPermissionDialog: StateFlow<Boolean> = _showPermissionDialog.asStateFlow()

    private val _detectedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val detectedApps: StateFlow<List<AppInfo>> = _detectedApps.asStateFlow()

    private val _hasUsagePermission = MutableStateFlow(false)
    val hasUsagePermission: StateFlow<Boolean> = _hasUsagePermission.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _isClaimingReward = MutableStateFlow(false)
    val isClaimingReward: StateFlow<Boolean> = _isClaimingReward.asStateFlow()

    init {
        checkUsagePermission()
        // Pre-load AdMob test rewarded ad
        adMobManager.loadRewardedAd()
        // Scan visible applications
        rescanApplications()

        // Continuous smooth auto-detection loop (instantly catches app installs from PlayStore, Chrome, etc.)
        viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(1500)
                try {
                    autoDetectNewlyInstalledApp()
                } catch (e: Exception) {
                    // ignore transient error
                }
            }
        }
    }

    fun checkUsagePermission() {
        val granted = usageTrackingRepository.hasUsageAccessPermission()
        _hasUsagePermission.value = granted
    }

    fun onResumeScreen() {
        checkUsagePermission()
        autoDetectNewlyInstalledApp()
        refreshUsageProgress()
        rescanApplications()
    }

    private fun autoDetectNewlyInstalledApp() {
        val session = activeSession.value ?: return
        if (!session.adWatched || !session.adClicked) return
        if (session.installationObserved && !session.targetPackageName.isNullOrEmpty()) return

        val newlyInstalledList = installationDetectionRepository.detectNewlyInstalled(
            snapshotString = session.installedPackagesSnapshot,
            sessionStartTimeMs = session.createdAt
        )
        if (newlyInstalledList.isNotEmpty()) {
            val newlyInstalled = newlyInstalledList.first()
            viewModelScope.launch {
                rewardRepository.setTargetApplication(
                    session.id,
                    newlyInstalled.packageName,
                    newlyInstalled.appName
                )
                _eventFlow.emit(SuperOfferUiEvent.ShowMessage("New app detected: ${newlyInstalled.appName} (${newlyInstalled.packageName})! Step 2 Completed ✓"))
            }
        }
    }

    fun checkAndAutoDetectNow() {
        val session = activeSession.value ?: return
        if (!session.adWatched || !session.adClicked) {
            viewModelScope.launch {
                _eventFlow.emit(SuperOfferUiEvent.ShowMessage("Pehle Step 1 complete karein (Ad dekh kar ad par click karein)."))
            }
            return
        }

        val newlyInstalledList = installationDetectionRepository.detectNewlyInstalled(
            snapshotString = session.installedPackagesSnapshot,
            sessionStartTimeMs = session.createdAt
        )
        if (newlyInstalledList.isNotEmpty()) {
            val newlyInstalled = newlyInstalledList.first()
            viewModelScope.launch {
                rewardRepository.setTargetApplication(
                    session.id,
                    newlyInstalled.packageName,
                    newlyInstalled.appName
                )
                _eventFlow.emit(SuperOfferUiEvent.ShowMessage("New app detected: ${newlyInstalled.appName}! Step 2 Completed ✓"))
            }
        } else {
            viewModelScope.launch {
                _eventFlow.emit(SuperOfferUiEvent.ShowMessage("Play Store se abhi tak koi naya app install nahi hua hai. Kripya app install karein."))
            }
        }
    }

    fun dismissPermissionDialog() {
        _showPermissionDialog.value = false
    }

    fun onSuperOfferCardClicked(onNavigateToDetails: () -> Unit) {
        checkUsagePermission()
        if (!_hasUsagePermission.value) {
            _showPermissionDialog.value = true
            return
        }

        viewModelScope.launch {
            val active = activeSession.value
            if (active != null) {
                onNavigateToDetails()
                return@launch
            }

            val snapshot = installationDetectionRepository.takeLaunchablePackagesSnapshot()
            val result = rewardRepository.unlockSuperOffer(snapshot)
            result.fold(
                onSuccess = {
                    onNavigateToDetails()
                },
                onFailure = { error ->
                    _eventFlow.emit(SuperOfferUiEvent.ShowMessage(error.message ?: "Failed to unlock offer"))
                }
            )
        }
    }

    // ADMOB STEP 1
    fun loadAd() {
        adMobManager.loadRewardedAd()
    }

    fun watchRewardedAd(activity: Activity) {
        val session = activeSession.value ?: return
        if (session.adWatched && session.adClicked && session.installationObserved && !session.targetPackageName.isNullOrEmpty()) {
            viewModelScope.launch {
                _eventFlow.emit(SuperOfferUiEvent.ShowMessage("Step 1 and Step 2 are already completed!"))
            }
            return
        }

        adMobManager.showRewardedAd(
            activity = activity,
            onAdCompletedAndClicked = { amount, type ->
                viewModelScope.launch {
                    rewardRepository.recordAdWatchedAndClicked(session.id)
                    _eventFlow.emit(SuperOfferUiEvent.ShowMessage("Ad watched and clicked successfully! Step 1 Completed ✓"))
                    autoDetectNewlyInstalledApp()
                }
            },
            onAdDismissedWithoutClick = {
                viewModelScope.launch {
                    rewardRepository.recordAdWatchedOnly(session.id)
                    _eventFlow.emit(SuperOfferUiEvent.ShowMessage("Ad par click karna zaroori hai! Kripya ad par click karein."))
                }
            },
            onAdDismissed = {
                viewModelScope.launch {
                    _eventFlow.emit(SuperOfferUiEvent.ShowMessage("Ad was closed before completing requirements."))
                }
            },
            onAdFailedToShow = { error ->
                viewModelScope.launch {
                    _eventFlow.emit(SuperOfferUiEvent.ShowMessage("Failed to display ad: $error"))
                }
            }
        )
    }

    // INSTALLATION STEP 2
    fun openGooglePlay() {
        val opened = installationDetectionRepository.openGooglePlayStore()
        if (!opened) {
            viewModelScope.launch {
                _eventFlow.emit(SuperOfferUiEvent.ShowMessage("Could not open Google Play Store directly. You can install an app manually."))
            }
        }
    }

    fun rescanApplications() {
        _isScanning.value = true
        val session = activeSession.value
        val snapshot = session?.installedPackagesSnapshot ?: ""

        // Check newly observed
        val newlyObserved = if (snapshot.isNotEmpty()) {
            installationDetectionRepository.detectNewlyObservedPackages(snapshot)
        } else {
            emptyList()
        }

        val allLaunchable = installationDetectionRepository.getLaunchableApplications()
        val combined = (newlyObserved + allLaunchable).distinctBy { it.packageName }
        _detectedApps.value = combined
        _isScanning.value = false
    }

    fun selectTargetApplication(appInfo: AppInfo) {
        val session = activeSession.value ?: return
        viewModelScope.launch {
            rewardRepository.setTargetApplication(session.id, appInfo.packageName, appInfo.appName)
            _eventFlow.emit(SuperOfferUiEvent.ShowMessage("Target app: ${appInfo.appName}. Step 2 completed!"))
        }
    }

    // USAGE TRACKING STEP 3
    fun playTargetApp() {
        val session = activeSession.value ?: return
        val targetPackage = session.targetPackageName
        if (targetPackage.isNullOrEmpty()) {
            viewModelScope.launch {
                _eventFlow.emit(SuperOfferUiEvent.ShowMessage("Please install the app from Play Store first."))
            }
            return
        }

        if (!_hasUsagePermission.value) {
            viewModelScope.launch {
                _eventFlow.emit(SuperOfferUiEvent.NavigateToPermissionScreen)
            }
            return
        }

        val result = installationDetectionRepository.launchApplication(targetPackage)
        result.onFailure { error ->
            viewModelScope.launch {
                _eventFlow.emit(SuperOfferUiEvent.ShowMessage("Could not launch $targetPackage: ${error.message}"))
            }
        }
    }

    fun refreshUsageProgress() {
        val session = activeSession.value ?: return
        val targetPackage = session.targetPackageName ?: return
        if (!_hasUsagePermission.value) return

        viewModelScope.launch {
            // Query usage from session creation time
            val secondsFromEvents = usageTrackingRepository.calculateTargetAppForegroundUsageSeconds(
                targetPackageName = targetPackage,
                startTimeMs = session.createdAt
            )

            // Or fallback if events pruned
            val fallbackSeconds = usageTrackingRepository.getFallbackUsageStatsSeconds(
                targetPackageName = targetPackage,
                startTimeMs = session.createdAt
            )

            val observed = maxOf(secondsFromEvents, fallbackSeconds, session.observedUsageSeconds)
            if (observed > session.observedUsageSeconds) {
                rewardRepository.updateUsageProgress(session.id, observed)
            }
        }
    }

    // CLAIM REWARD STEP 4
    fun claimCoinReward() {
        val session = activeSession.value ?: return
        if (_isClaimingReward.value) return

        _isClaimingReward.value = true
        viewModelScope.launch {
            try {
                val result = rewardRepository.completeOfferAndClaimCoins(session.id)
                result.fold(
                    onSuccess = { coins ->
                        _eventFlow.emit(SuperOfferUiEvent.ShowMessage("Congratulations! +$coins Coins added to your Wallet!"))
                        _eventFlow.emit(SuperOfferUiEvent.OfferCompletedSuccess)
                    },
                    onFailure = { error ->
                        _eventFlow.emit(SuperOfferUiEvent.ShowMessage(error.message ?: "Failed to claim reward"))
                    }
                )
            } finally {
                _isClaimingReward.value = false
            }
        }
    }
}

class SuperOfferViewModelFactory(
    private val rewardRepository: RewardRepository,
    private val installationDetectionRepository: InstallationDetectionRepository,
    private val usageTrackingRepository: UsageTrackingRepository,
    private val adMobManager: AdMobRewardedAdManager
) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return SuperOfferViewModel(
            rewardRepository,
            installationDetectionRepository,
            usageTrackingRepository,
            adMobManager
        ) as T
    }
}
