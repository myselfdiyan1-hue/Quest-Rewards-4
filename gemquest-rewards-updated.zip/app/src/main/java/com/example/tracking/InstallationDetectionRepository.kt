package com.example.tracking

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import com.example.data.model.AppInfo

class InstallationDetectionRepository(private val context: Context) {

    /**
     * Gets all currently launchable applications visible to this app.
     * Uses Intent.ACTION_MAIN + Intent.CATEGORY_LAUNCHER which works with
     * the <queries> manifest declaration on Android 11+ without QUERY_ALL_PACKAGES.
     */
    fun getLaunchableApplications(): List<AppInfo> {
        val packageManager = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolvedActivities = packageManager.queryIntentActivities(mainIntent, 0)
        val ownPackageName = context.packageName

        return resolvedActivities
            .mapNotNull { resolveInfo ->
                val packageName = resolveInfo.activityInfo.packageName
                if (packageName == ownPackageName) return@mapNotNull null

                val appName = try {
                    resolveInfo.loadLabel(packageManager).toString()
                } catch (e: Exception) {
                    packageName
                }
                AppInfo(
                    packageName = packageName,
                    appName = appName,
                    isNewlyObserved = false
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.appName.lowercase() }
    }

    /**
     * Takes a snapshot of currently visible launchable packages as a comma-separated string.
     */
    fun takeLaunchablePackagesSnapshot(): String {
        return getLaunchableApplications().joinToString(",") { it.packageName }
    }

    /**
     * Detects applications that were installed or updated after or around the session start time.
     * Supports installations from Google Play Store, Play Store half-sheet overlay,
     * Chrome browser download, direct APK install, etc.
     */
    fun detectRecentlyInstalledApps(sessionStartTimeMs: Long): List<AppInfo> {
        val launchableApps = getLaunchableApplications()
        val pm = context.packageManager
        // 5-minute buffer before session start to catch downloads initiated just before or right around start
        val thresholdTime = (sessionStartTimeMs - 300_000L).coerceAtLeast(0L)

        return launchableApps.filter { app ->
            try {
                val pkgInfo = pm.getPackageInfo(app.packageName, 0)
                val installTime = pkgInfo.firstInstallTime
                val updateTime = pkgInfo.lastUpdateTime
                installTime >= thresholdTime || updateTime >= thresholdTime
            } catch (e: Exception) {
                false
            }
        }.map { it.copy(isNewlyObserved = true) }
    }

    /**
     * Compares the current launchable packages with a previous snapshot string.
     * Returns the list of applications observed now that were NOT present in the snapshot.
     */
    fun detectNewlyObservedPackages(snapshotString: String): List<AppInfo> {
        val previousPackages = snapshotString.split(",")
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toSet()

        val currentApps = getLaunchableApplications()
        return currentApps.filter { app ->
            !previousPackages.contains(app.packageName)
        }.map { it.copy(isNewlyObserved = true) }
    }

    /**
     * Instant and reliable combined detection:
     * Checks both firstInstallTime / lastUpdateTime and snapshot diff to catch ANY app
     * installed via Google Play Store (half or full sheet), Chrome browser, or package installer.
     */
    fun detectNewlyInstalled(snapshotString: String, sessionStartTimeMs: Long): List<AppInfo> {
        val byTime = detectRecentlyInstalledApps(sessionStartTimeMs)
        val bySnapshot = if (snapshotString.isNotEmpty()) {
            detectNewlyObservedPackages(snapshotString)
        } else {
            emptyList()
        }
        return (bySnapshot + byTime).distinctBy { it.packageName }
    }

    /**
     * Attempts to open Google Play Store to allow the user to install an application.
     */
    fun openGooglePlayStore(): Boolean {
        return try {
            val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=free+games")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(marketIntent)
            true
        } catch (e: Exception) {
            try {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=free+games&c=apps")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
                true
            } catch (ex: Exception) {
                false
            }
        }
    }

    /**
     * Resolves launch intent and opens the selected application.
     */
    fun launchApplication(packageName: String): Result<Unit> {
        return try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                Result.success(Unit)
            } else {
                Result.failure(IllegalStateException("No launchable intent found for package: $packageName"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Checks if a specific package is currently installed and launchable.
     */
    fun isPackageInstalled(packageName: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun getAppNameForPackage(packageName: String): String {
        return try {
            val pm = context.packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            packageName
        }
    }
}
