package com.example.ui.wallet

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.firebase.FirebaseManager
import com.example.data.firebase.PayoutMethod
import com.example.data.local.UserBalanceEntity
import com.example.data.model.TestConfig
import com.example.data.repository.RewardRepository
import com.example.ui.components.GoldCoinIcon
import com.example.ui.theme.CardWhite
import com.example.ui.theme.HeaderBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.SecondaryText
import kotlinx.coroutines.launch

@Composable
fun WalletScreen(
    rewardRepository: RewardRepository,
    firebaseManager: FirebaseManager,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val balance by rewardRepository.balanceFlow.collectAsStateWithLifecycle(
        initialValue = UserBalanceEntity(id = 1, coins = TestConfig.INITIAL_COINS, gems = TestConfig.INITIAL_GEMS)
    )

    val payoutMethods by firebaseManager.payoutMethods.collectAsStateWithLifecycle()
    val appConfig by firebaseManager.appConfig.collectAsStateWithLifecycle()
    val isBlocked by firebaseManager.isUserBlocked.collectAsStateWithLifecycle()

    var selectedMethodForRedeem by remember { mutableStateOf<PayoutMethod?>(null) }
    var accountInput by remember { mutableStateOf("") }
    var inputError by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MainBackground)
            .testTag("wallet_screen")
    ) {
        // Top Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = HeaderBackground,
            shadowElevation = 3.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("wallet_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = PrimaryText
                    )
                }
                Text(
                    text = "Wallet & Withdraw",
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryText
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Available Coins Card
            item {
                BigAvailableCoinsCard(coins = balance.coins)
            }

            // Blocked User Banner
            if (isBlocked) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2)),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFEF4444))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Lock,
                                contentDescription = null,
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Account Blocked by Admin. Withdrawals and reward claims are currently restricted.",
                                fontSize = 12.sp,
                                color = Color(0xFFB91C1C),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Conversion Info Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                    border = BorderStroke(1.dp, Color(0xFFFCD34D))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GoldCoinIcon(size = 26.dp)
                        Column {
                            Text(
                                text = "Conversion Rate: ${appConfig.conversionRateText}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF92400E)
                            )
                            Text(
                                text = "Select a withdrawal method below to transfer your earnings.",
                                fontSize = 11.sp,
                                color = Color(0xFFB45309),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // 2. Dynamic Payout Methods Section Header
            item {
                Text(
                    text = "Select Payout Method",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = PrimaryText,
                    modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                )
            }

            if (payoutMethods.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("wallet_empty_methods_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = CardWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Wallet,
                                contentDescription = null,
                                tint = Color(0xFFCBD5E1),
                                modifier = Modifier.size(34.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No Payment Methods Active",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryText
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Payment methods added from the Admin Panel will appear here.",
                                fontSize = 12.sp,
                                color = SecondaryText,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(payoutMethods, key = { it.id }) { method ->
                    DynamicPayoutMethodCard(
                        method = method,
                        userCoins = balance.coins,
                        isBlocked = isBlocked,
                        onClick = {
                            if (isBlocked) {
                                Toast.makeText(context, "Your account is blocked by Admin.", Toast.LENGTH_SHORT).show()
                            } else {
                                selectedMethodForRedeem = method
                                accountInput = ""
                                inputError = null
                            }
                        }
                    )
                }
            }

            // Safe & Secure Note
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Security,
                        contentDescription = null,
                        tint = Color(0xFF16A34A),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "100% Safe & Secure Instant Payouts",
                        fontSize = 11.sp,
                        color = Color(0xFF16A34A),
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }

    // Dynamic Withdrawal Dialog
    if (selectedMethodForRedeem != null) {
        val method = selectedMethodForRedeem!!
        Dialog(onDismissRequest = {
            if (!isSubmitting) selectedMethodForRedeem = null
        }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(22.dp),
                color = CardWhite,
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier.padding(22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Redeem ${method.currency}${method.cashAmount.toInt()}",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = PrimaryText
                        )
                        IconButton(
                            onClick = { if (!isSubmitting) selectedMethodForRedeem = null },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(imageVector = Icons.Filled.Close, contentDescription = "Close", tint = SecondaryText)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Method: ${method.title}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF3B82F6),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9))
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Required Coins:", fontSize = 12.sp, color = SecondaryText)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                GoldCoinIcon(size = 14.dp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${method.minCoins}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFFB45309)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = accountInput,
                        onValueChange = {
                            accountInput = it
                            inputError = null
                        },
                        label = { Text(method.inputLabel) },
                        placeholder = { Text(method.inputPlaceholder, fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("payout_account_input"),
                        shape = RoundedCornerShape(12.dp),
                        isError = inputError != null,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF3B82F6),
                            unfocusedBorderColor = Color(0xFFCBD5E1)
                        )
                    )

                    if (inputError != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = inputError ?: "",
                            fontSize = 11.sp,
                            color = Color(0xFFDC2626),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            val trimmed = accountInput.trim()
                            if (trimmed.isBlank() || trimmed.length < 4) {
                                inputError = "Please enter valid ${method.inputLabel}"
                                return@Button
                            }

                            if (balance.coins < method.minCoins) {
                                inputError = "Insufficient coins! You need ${method.minCoins} coins."
                                return@Button
                            }

                            isSubmitting = true
                            inputError = null

                            coroutineScope.launch {
                                val result = rewardRepository.requestPayout(
                                    payoutMethod = method,
                                    inrAmount = method.cashAmount,
                                    coinsNeeded = method.minCoins,
                                    accountDetail = trimmed
                                )
                                isSubmitting = false
                                if (result.isSuccess) {
                                    Toast.makeText(
                                        context,
                                        "Withdrawal request of ${method.currency}${method.cashAmount.toInt()} submitted successfully!",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    selectedMethodForRedeem = null
                                } else {
                                    inputError = result.exceptionOrNull()?.localizedMessage
                                        ?: "Failed to submit withdrawal request."
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_withdrawal_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                        shape = RoundedCornerShape(14.dp),
                        enabled = !isSubmitting
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Processing Withdrawal...", color = Color.White)
                        } else {
                            Text(
                                "Confirm & Withdraw ${method.currency}${method.cashAmount.toInt()}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BigAvailableCoinsCard(coins: Int) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("available_coins_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0F172A),
                            Color(0xFF1E293B),
                            Color(0xFF1E1B4B)
                        )
                    )
                )
                .padding(24.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(Color(0xFFFDE68A), Color(0xFFF59E0B), Color(0xFFD97706))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    GoldCoinIcon(modifier = Modifier.size(38.dp))
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "TOTAL AVAILABLE COINS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "$coins",
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Coins",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFFCD34D)
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "≈ ₹${"%.2f".format(coins / 100.0)} Real Cash Value",
                    fontSize = 13.sp,
                    color = Color(0xFF4ADE80),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun DynamicPayoutMethodCard(
    method: PayoutMethod,
    userCoins: Int,
    isBlocked: Boolean,
    onClick: () -> Unit
) {
    val isEligible = userCoins >= method.minCoins && !isBlocked
    val progress = (userCoins.toFloat() / method.minCoins.toFloat()).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "progress"
    )

    val iconVector: ImageVector = when (method.iconType.uppercase()) {
        "PAYTM" -> Icons.Filled.Wallet
        "UPI" -> Icons.Filled.QrCode2
        "BANK" -> Icons.Filled.AccountBalance
        else -> Icons.Filled.Payment
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .testTag("payout_card_${method.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFEFF6FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = iconVector,
                            contentDescription = method.title,
                            tint = Color(0xFF2563EB),
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Text(
                            text = method.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryText
                        )
                        Text(
                            text = method.subtitle.ifBlank { "Instant Transfer" },
                            fontSize = 11.sp,
                            color = SecondaryText
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isEligible) Color(0xFFDCFCE7) else Color(0xFFF1F5F9))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${method.currency}${method.cashAmount.toInt()}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isEligible) Color(0xFF15803D) else Color(0xFF64748B)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Progress bar toward minCoins
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Min Payout: ${method.minCoins} Coins",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = SecondaryText
                )

                Text(
                    text = if (isEligible) "Ready to Redeem ✓" else "${method.minCoins - userCoins} coins needed",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isEligible) Color(0xFF16A34A) else Color(0xFFEA580C)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE2E8F0))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animatedProgress)
                        .height(6.dp)
                        .clip(CircleShape)
                        .background(
                            if (isEligible) Color(0xFF16A34A) else Color(0xFF3B82F6)
                        )
                )
            }
        }
    }
}
