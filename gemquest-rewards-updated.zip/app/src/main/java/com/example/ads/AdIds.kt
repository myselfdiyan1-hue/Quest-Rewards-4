package com.example.ads

import com.example.BuildConfig

/**
 * AdMob unit IDs. Values come from BuildConfig:
 * debug builds -> Google test IDs, release builds -> production IDs.
 */
object AdIds {
    val REWARDED: String = BuildConfig.ADMOB_REWARDED_ID
    val INTERSTITIAL: String = BuildConfig.ADMOB_INTERSTITIAL_ID
    val BANNER: String = BuildConfig.ADMOB_BANNER_ID
}
