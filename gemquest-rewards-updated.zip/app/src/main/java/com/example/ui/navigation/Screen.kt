package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Tasks : Screen("tasks")
    object SuperOfferHub : Screen("super_offer_hub")
    object SuperOfferDetails : Screen("super_offer_details")
    object Leaderboard : Screen("leaderboard")
    object Wallet : Screen("wallet")
    object Profile : Screen("profile")
    object ImageFinder : Screen("image_finder")
    object UsagePermission : Screen("usage_permission")
    object TaskHistory : Screen("task_history")
    object PayoutDetail : Screen("payout_detail/{method}") {
        fun createRoute(method: String) = "payout_detail/$method"
    }
    object Login : Screen("login")
}
