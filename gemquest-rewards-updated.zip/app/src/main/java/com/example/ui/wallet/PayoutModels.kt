package com.example.ui.wallet

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class PayoutMethodType(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val primaryColor: Color,
    val gradientColors: List<Color>,
    val inputPlaceholder: String,
    val inputLabel: String
) {
    PAYTM(
        id = "PAYTM",
        title = "Paytm Wallet",
        subtitle = "Fast & Instant Transfer",
        icon = Icons.Filled.Wallet,
        primaryColor = Color(0xFF00B9F5),
        gradientColors = listOf(Color(0xFF002E6E), Color(0xFF00B9F5), Color(0xFF00E5FF)),
        inputPlaceholder = "Enter 10-digit Paytm Mobile No.",
        inputLabel = "Paytm Number"
    ),
    UPI(
        id = "UPI",
        title = "UPI ID / QR",
        subtitle = "GPay, PhonePe, BHIM & Any UPI",
        icon = Icons.Filled.QrCode2,
        primaryColor = Color(0xFF5E27CD),
        gradientColors = listOf(Color(0xFF341F97), Color(0xFF5E27CD), Color(0xFF9B51E0)),
        inputPlaceholder = "username@okhdfcbank / number@upi",
        inputLabel = "UPI ID (VPA)"
    ),
    BANK(
        id = "BANK",
        title = "Bank Transfer",
        subtitle = "Direct IMPS / NEFT Transfer",
        icon = Icons.Filled.AccountBalance,
        primaryColor = Color(0xFF10B981),
        gradientColors = listOf(Color(0xFF064E3B), Color(0xFF059669), Color(0xFF10B981)),
        inputPlaceholder = "Account Number & IFSC Code",
        inputLabel = "Bank Account & IFSC"
    )
}

data class PayoutTier(
    val inrAmount: Int,
    val requiredCoins: Int
)

val PAYOUT_TIERS = listOf(
    PayoutTier(inrAmount = 10, requiredCoins = 1000),
    PayoutTier(inrAmount = 20, requiredCoins = 2000),
    PayoutTier(inrAmount = 30, requiredCoins = 3000),
    PayoutTier(inrAmount = 40, requiredCoins = 4000)
)
