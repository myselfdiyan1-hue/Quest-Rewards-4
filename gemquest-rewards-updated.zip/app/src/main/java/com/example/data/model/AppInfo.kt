package com.example.data.model

data class AppInfo(
    val packageName: String,
    val appName: String,
    val isNewlyObserved: Boolean = false
)

enum class StepStatus {
    NOT_STARTED,
    IN_PROGRESS,
    PENDING_VERIFICATION,
    COMPLETED,
    REJECTED
}

enum class OfferSessionStatus {
    NOT_STARTED,
    IN_PROGRESS,
    PENDING_VERIFICATION,
    COMPLETED,
    REJECTED
}
