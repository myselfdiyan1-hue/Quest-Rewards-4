package com.example

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.auth.LoginScreen
import com.example.ui.components.GoldCoinIcon
import com.example.ui.home.HomeScreen
import com.example.ui.home.HomeViewModel
import com.example.ui.home.HomeViewModelFactory
import com.example.ui.imagefinder.ImageFinderScreen
import com.example.ui.imagefinder.ImageFinderViewModel
import com.example.ui.imagefinder.ImageFinderViewModelFactory
import com.example.ui.leaderboard.LeaderboardScreen
import com.example.ui.navigation.BottomNavBar
import com.example.ui.navigation.Screen
import com.example.ui.profile.ProfileScreen
import com.example.ui.superoffer.SuperOfferHubScreen
import com.example.ui.superoffer.SuperOfferScreen
import com.example.ui.superoffer.SuperOfferViewModel
import com.example.ui.superoffer.SuperOfferViewModelFactory
import com.example.ui.superoffer.UsagePermissionScreen
import com.example.ui.taskhistory.TaskHistoryScreen
import com.example.ui.tasks.MoreTasksScreen
import com.example.ui.theme.GemQuestTheme
import com.example.ui.theme.MainBackground
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.SecondaryText
import com.example.ui.wallet.PayoutDetailScreen
import com.example.ui.wallet.WalletScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as GemQuestApplication

        setContent {
            GemQuestTheme {
                val coroutineScope = androidx.compose.runtime.rememberCoroutineScope()
                val isLoggedIn by app.firebaseManager.isLoggedIn.collectAsStateWithLifecycle()
                val isUserBlocked by app.firebaseManager.isUserBlocked.collectAsStateWithLifecycle()

                if (!isLoggedIn) {
                    // Unauthenticated Users: Google-only Login Screen
                    LoginScreen(
                        firebaseManager = app.firebaseManager,
                        rewardRepository = app.rewardRepository,
                        onLoginSuccess = {
                            // Session established; isLoggedIn turns true immediately
                        }
                    )
                } else if (isUserBlocked) {
                    // Blocked / Suspended User Screen
                    BlockedUserScreen(
                        onLogout = {
                            coroutineScope.launch {
                                app.rewardRepository.resetTestData()
                            }
                            app.firebaseManager.logout()
                        }
                    )
                } else {
                    // Authenticated Users: Full Application with Bottom Navigation
                    val navController = rememberNavController()
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Home.route

                    val topLevelRoutes = listOf(
                        Screen.Home.route,
                        Screen.Tasks.route,
                        Screen.Leaderboard.route,
                        Screen.Wallet.route
                    )
                    val showBottomBar = currentRoute in topLevelRoutes

                    val homeViewModel: HomeViewModel = viewModel(
                        factory = HomeViewModelFactory(
                            app.rewardRepository,
                            app.installationDetectionRepository
                        )
                    )

                    val superOfferViewModel: SuperOfferViewModel = viewModel(
                        factory = SuperOfferViewModelFactory(
                            app.rewardRepository,
                            app.installationDetectionRepository,
                            app.usageTrackingRepository,
                            app.adMobRewardedAdManager
                        )
                    )

                    val imageFinderViewModel: ImageFinderViewModel = viewModel(
                        factory = ImageFinderViewModelFactory(
                            app.rewardRepository,
                            app.adMobRewardedAdManager
                        )
                    )

                    Scaffold(
                        bottomBar = {
                            if (showBottomBar) {
                                BottomNavBar(
                                    currentRoute = currentRoute,
                                    onNavigate = { route ->
                                        if (currentRoute != route) {
                                            navController.navigate(route) {
                                                popUpTo(Screen.Home.route) {
                                                    saveState = true
                                                }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = Screen.Home.route,
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable(Screen.Home.route) {
                                HomeScreen(
                                    viewModel = homeViewModel,
                                    firebaseManager = app.firebaseManager,
                                    rewardRepository = app.rewardRepository,
                                    onNavigateToWallet = {
                                        navController.navigate(Screen.Wallet.route)
                                    },
                                    onNavigateToImageFinder = {
                                        navController.navigate(Screen.ImageFinder.route)
                                    },
                                    onNavigateToSuperOffer = {
                                        navController.navigate(Screen.SuperOfferHub.route)
                                    },
                                    onNavigateToMoreTasks = {
                                        navController.navigate(Screen.Tasks.route)
                                    },
                                    onNavigateToTaskHistory = {
                                        navController.navigate(Screen.TaskHistory.route)
                                    },
                                    onNavigateToProfile = {
                                        navController.navigate(Screen.Profile.route)
                                    },
                                    onLogout = {
                                        coroutineScope.launch {
                                            app.rewardRepository.resetTestData()
                                        }
                                        app.firebaseManager.logout()
                                    }
                                )
                            }

                            composable(Screen.Tasks.route) {
                                MoreTasksScreen(
                                    rewardRepository = app.rewardRepository,
                                    firebaseManager = app.firebaseManager,
                                    adMobRewardedAdManager = app.adMobRewardedAdManager,
                                    onNavigateToSuperOffer = {
                                        navController.navigate(Screen.SuperOfferHub.route)
                                    }
                                )
                            }

                            composable(Screen.SuperOfferHub.route) {
                                SuperOfferHubScreen(
                                    viewModel = superOfferViewModel,
                                    onNavigateBack = {
                                        navController.popBackStack()
                                    },
                                    onNavigateToDetails = { _ ->
                                        navController.navigate(Screen.SuperOfferDetails.route)
                                    }
                                )
                            }

                            composable(Screen.Leaderboard.route) {
                                LeaderboardScreen(
                                    rewardRepository = app.rewardRepository,
                                    firebaseManager = app.firebaseManager,
                                    onNavigateBack = {
                                        navController.popBackStack()
                                    }
                                )
                            }

                            composable(Screen.Wallet.route) {
                                WalletScreen(
                                    rewardRepository = app.rewardRepository,
                                    firebaseManager = app.firebaseManager,
                                    onNavigateBack = {
                                        navController.popBackStack()
                                    }
                                )
                            }

                            composable(
                                route = Screen.PayoutDetail.route
                            ) { backStackEntry ->
                                val method = backStackEntry.arguments?.getString("method") ?: "UPI"
                                PayoutDetailScreen(
                                    methodId = method,
                                    rewardRepository = app.rewardRepository,
                                    onNavigateBack = {
                                        navController.popBackStack()
                                    }
                                )
                            }

                            composable(Screen.Profile.route) {
                                ProfileScreen(
                                    rewardRepository = app.rewardRepository,
                                    firebaseManager = app.firebaseManager,
                                    onNavigateBack = {
                                        navController.popBackStack()
                                    },
                                    onNavigateToTaskHistory = {
                                        navController.navigate(Screen.TaskHistory.route)
                                    },
                                    onNavigateToLogin = {
                                        coroutineScope.launch {
                                            app.rewardRepository.resetTestData()
                                        }
                                        app.firebaseManager.logout()
                                    }
                                )
                            }

                            composable(Screen.ImageFinder.route) {
                                ImageFinderScreen(
                                    viewModel = imageFinderViewModel,
                                    onNavigateBack = {
                                        navController.popBackStack()
                                    }
                                )
                            }

                            composable(Screen.SuperOfferDetails.route) {
                                SuperOfferScreen(
                                    viewModel = superOfferViewModel,
                                    onNavigateBack = {
                                        navController.popBackStack()
                                    },
                                    onNavigateToPermission = {
                                        navController.navigate(Screen.UsagePermission.route)
                                    }
                                )
                            }

                            composable(Screen.UsagePermission.route) {
                                val context = LocalContext.current
                                val hasUsagePermission by superOfferViewModel.hasUsagePermission.collectAsStateWithLifecycle()
                                UsagePermissionScreen(
                                    onAllowClicked = {
                                        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                                        context.startActivity(intent)
                                    },
                                    onNavigateBack = {
                                        navController.popBackStack()
                                    },
                                    isPermissionGranted = hasUsagePermission
                                )
                            }

                            composable(Screen.TaskHistory.route) {
                                TaskHistoryScreen(
                                    rewardRepository = app.rewardRepository,
                                    onNavigateBack = {
                                        navController.popBackStack()
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BlockedUserScreen(onLogout: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MainBackground)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFEE2E2)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = "Blocked",
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Account Suspended",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF991B1B)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Your account has been blocked by the Administrator. All earning, task completion, and withdrawals have been suspended.",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B),
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onLogout,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("Log Out / Switch Account", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}
