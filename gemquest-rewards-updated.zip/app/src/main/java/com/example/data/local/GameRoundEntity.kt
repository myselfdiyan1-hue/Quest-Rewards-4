package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_rounds")
data class GameRoundEntity(
    @PrimaryKey val roundId: String,
    val completed: Boolean = true,
    val gemAwarded: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)
