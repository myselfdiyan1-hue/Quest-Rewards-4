package com.example.ui.leaderboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.firebase.FirebaseManager
import com.example.data.firebase.LeaderboardEntry
import com.example.data.firebase.LeaderboardTab
import com.example.data.repository.RewardRepository
import com.example.ui.components.GoldCoinIcon
import com.example.ui.theme.CardWhite
import com.example.ui.theme.HeaderBackground
import com.example.ui.theme.MainBackground
import com.example.ui.theme.PrimaryBlue
import com.example.ui.theme.PrimaryText
import com.example.ui.theme.SecondaryText

@Composable
fun LeaderboardScreen(
    rewardRepository: RewardRepository,
    firebaseManager: FirebaseManager,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(LeaderboardTab.DAILY) }
    val playersFlow = remember(selectedTab) {
        firebaseManager.observeLeaderboard(selectedTab)
    }
    val players by playersFlow.collectAsStateWithLifecycle(initialValue = emptyList())

    val top3 = players.take(3)
    val remainingPlayers = if (players.size > 3) players.drop(3) else emptyList()
    val currentUserEntry = players.firstOrNull { it.isCurrentUser }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MainBackground)
            .testTag("leaderboard_screen")
    ) {
        // Top Header + Daily / Weekly Segmented Switcher
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = HeaderBackground,
            shadowElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("leaderboard_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = PrimaryText
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Earning Leaderboard",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryText
                        )
                        Text(
                            text = if (selectedTab == LeaderboardTab.DAILY) {
                                "Top daily coin earners today"
                            } else {
                                "Top weekly coin earners this week"
                            },
                            fontSize = 12.sp,
                            color = SecondaryText,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Daily vs Weekly Tab Selector
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFFE2E8F0))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    LeaderboardTab.entries.forEach { tab ->
                        val isSelected = selectedTab == tab
                        val tabTag = if (tab == LeaderboardTab.DAILY) {
                            "leaderboard_tab_daily"
                        } else {
                            "leaderboard_tab_weekly"
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isSelected) PrimaryBlue else Color.Transparent
                                )
                                .clickable { selectedTab = tab }
                                .padding(vertical = 10.dp, horizontal = 12.dp)
                                .testTag(tabTag),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = if (tab == LeaderboardTab.DAILY) {
                                        Icons.Filled.Today
                                    } else {
                                        Icons.Filled.CalendarMonth
                                    },
                                    contentDescription = tab.label,
                                    tint = if (isSelected) Color.White else SecondaryText,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${tab.label} Earning",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else SecondaryText
                                )
                            }
                        }
                    }
                }
            }
        }

        if (players.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(36.dp),
                        color = PrimaryBlue,
                        strokeWidth = 3.dp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Loading ${selectedTab.label.lowercase()} earnings...",
                        fontSize = 14.sp,
                        color = SecondaryText
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Current User's Daily & Weekly Earnings Overview Banner
                if (currentUserEntry != null) {
                    item {
                        UserEarningSummaryBanner(
                            user = currentUserEntry,
                            selectedTab = selectedTab
                        )
                    }
                }

                // Top 3 Podium Section
                if (top3.isNotEmpty()) {
                    item {
                        PodiumSection(
                            top3 = top3,
                            selectedTab = selectedTab
                        )
                    }
                }

                // List of remaining ranks
                items(remainingPlayers, key = { it.userId }) { player ->
                    LeaderboardRow(
                        player = player,
                        selectedTab = selectedTab
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }

        // Sticky Bottom Card for Current User's Rank & Earning
        if (currentUserEntry != null) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = CardWhite,
                shadowElevation = 8.dp,
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF3B82F6)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "#${currentUserEntry.rank}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${currentUserEntry.displayName} (You)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryText,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFDCFCE7))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = selectedTab.label,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF16A34A)
                                )
                            }
                        }
                        Text(
                            text = "Today: +${currentUserEntry.dailyCoins} Coins  •  Weekly: +${currentUserEntry.weeklyCoins} Coins",
                            fontSize = 11.sp,
                            color = SecondaryText
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        GoldCoinIcon(modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "+${currentUserEntry.displayedCoins}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFB45309)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun UserEarningSummaryBanner(
    user: LeaderboardEntry,
    selectedTab: LeaderboardTab
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("user_earning_summary_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Daily Earned Column
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Today's Earning",
                    fontSize = 11.sp,
                    fontWeight = if (selectedTab == LeaderboardTab.DAILY) FontWeight.Bold else FontWeight.Medium,
                    color = if (selectedTab == LeaderboardTab.DAILY) PrimaryBlue else SecondaryText
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GoldCoinIcon(modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "+${user.dailyCoins}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = PrimaryText
                    )
                }
            }

            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(34.dp)
                    .background(Color(0xFFE2E8F0))
            )

            // Weekly Earned Column
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Weekly Earning",
                    fontSize = 11.sp,
                    fontWeight = if (selectedTab == LeaderboardTab.WEEKLY) FontWeight.Bold else FontWeight.Medium,
                    color = if (selectedTab == LeaderboardTab.WEEKLY) PrimaryBlue else SecondaryText
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GoldCoinIcon(modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "+${user.weeklyCoins}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = PrimaryText
                    )
                }
            }

            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(34.dp)
                    .background(Color(0xFFE2E8F0))
            )

            // Rank Column
            Column(
                modifier = Modifier.weight(0.8f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "${selectedTab.label} Rank",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = SecondaryText
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "#${user.rank}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = PrimaryBlue
                )
            }
        }
    }
}

@Composable
fun PodiumSection(
    top3: List<LeaderboardEntry>,
    selectedTab: LeaderboardTab
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("leaderboard_podium_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF1E293B),
                            Color(0xFF0F172A),
                            Color(0xFF1E1B4B)
                        )
                    )
                )
                .padding(vertical = 20.dp, horizontal = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                // Rank 2 (Silver)
                if (top3.size > 1) {
                    PodiumColumn(
                        player = top3[1],
                        rank = 2,
                        pedestalHeight = 80.dp,
                        crownColor = Color(0xFF94A3B8),
                        pedestalColor = Color(0xFF334155),
                        selectedTab = selectedTab
                    )
                } else {
                    Spacer(modifier = Modifier.width(70.dp))
                }

                // Rank 1 (Gold - Center)
                if (top3.isNotEmpty()) {
                    PodiumColumn(
                        player = top3[0],
                        rank = 1,
                        pedestalHeight = 110.dp,
                        crownColor = Color(0xFFFBBF24),
                        pedestalColor = Color(0xFF78350F),
                        selectedTab = selectedTab
                    )
                }

                // Rank 3 (Bronze)
                if (top3.size > 2) {
                    PodiumColumn(
                        player = top3[2],
                        rank = 3,
                        pedestalHeight = 65.dp,
                        crownColor = Color(0xFFD97706),
                        pedestalColor = Color(0xFF451A03),
                        selectedTab = selectedTab
                    )
                } else {
                    Spacer(modifier = Modifier.width(70.dp))
                }
            }
        }
    }
}

@Composable
fun PodiumColumn(
    player: LeaderboardEntry,
    rank: Int,
    pedestalHeight: androidx.compose.ui.unit.Dp,
    crownColor: Color,
    pedestalColor: Color,
    selectedTab: LeaderboardTab
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(98.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.EmojiEvents,
            contentDescription = "Rank $rank",
            tint = crownColor,
            modifier = Modifier.size(if (rank == 1) 28.dp else 22.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        Box(
            modifier = Modifier
                .size(if (rank == 1) 54.dp else 46.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(crownColor, Color.DarkGray)
                    )
                )
                .border(2.dp, crownColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            val initial = player.displayName.firstOrNull()?.uppercaseChar()?.toString() ?: "U"
            Text(
                text = initial,
                fontSize = if (rank == 1) 20.sp else 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = player.displayName,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            GoldCoinIcon(modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = "+${player.displayedCoins}",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFDE68A)
            )
        }

        Text(
            text = if (selectedTab == LeaderboardTab.DAILY) "Today" else "This Week",
            fontSize = 9.sp,
            color = Color(0xFF94A3B8)
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Pedestal block
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(pedestalHeight)
                .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                .background(pedestalColor),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "#$rank",
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = Color.White.copy(alpha = 0.85f)
            )
        }
    }
}

@Composable
fun LeaderboardRow(
    player: LeaderboardEntry,
    selectedTab: LeaderboardTab
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("leaderboard_row_${player.rank}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (player.isCurrentUser) Color(0xFFFEF3C7) else CardWhite
        ),
        border = if (player.isCurrentUser) {
            CardDefaults.outlinedCardBorder().copy(
                brush = Brush.horizontalGradient(listOf(Color(0xFFF59E0B), Color(0xFFD97706)))
            )
        } else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFF1F5F9)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${player.rank}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryText
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE2E8F0)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = player.displayName.firstOrNull()?.uppercaseChar()?.toString() ?: "U",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = PrimaryText
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (player.isCurrentUser) "${player.displayName} (You)" else player.displayName,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "Today: +${player.dailyCoins}  •  Weekly: +${player.weeklyCoins}",
                    fontSize = 11.sp,
                    color = SecondaryText
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GoldCoinIcon(modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "+${player.displayedCoins}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFB45309)
                    )
                }
                Text(
                    text = if (selectedTab == LeaderboardTab.DAILY) "Daily" else "Weekly",
                    fontSize = 10.sp,
                    color = SecondaryText
                )
            }
        }
    }
}
