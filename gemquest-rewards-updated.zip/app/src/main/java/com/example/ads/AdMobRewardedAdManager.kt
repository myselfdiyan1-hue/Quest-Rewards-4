package com.example.ads

import android.app.Activity
import android.content.Context
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class AdState {
    object Idle : AdState()
    object Loading : AdState()
    object Ready : AdState()
    data class Error(val message: String) : AdState()
    object Showing : AdState()
    data class RewardEarned(val amount: Int, val type: String) : AdState()
}

class AdMobRewardedAdManager(private val context: Context) {

    private val TAG = "AdMobRewardedAdManager"
    private var rewardedAd: RewardedAd? = null

    private val _adState = MutableStateFlow<AdState>(AdState.Idle)
    val adState: StateFlow<AdState> = _adState.asStateFlow()

    private var isAdRewardedForCurrentShow = false
    private var wasAdClicked = false
    private var lastRewardAmount = 0
    private var lastRewardType = "Coins"

    init {
        try {
            val reqConfig = RequestConfiguration.Builder()
                .setTestDeviceIds(listOf(AdRequest.DEVICE_ID_EMULATOR))
                .build()
            MobileAds.setRequestConfiguration(reqConfig)
            MobileAds.initialize(context) { initializationStatus ->
                Log.d(TAG, "AdMob initialized successfully: $initializationStatus")
                loadRewardedAd()
            }
        } catch (e: Exception) {
            Log.e(TAG, "AdMob initialization error", e)
        }
    }

    fun isAdLoaded(): Boolean = rewardedAd != null

    /**
     * Loads the rewarded ad (test ID in debug, production ID in release).
     */
    fun loadRewardedAd() {
        if (_adState.value is AdState.Loading) {
            return
        }

        _adState.value = AdState.Loading

        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            AdIds.REWARDED,
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    Log.d(TAG, "AdMob Rewarded Ad Loaded successfully.")
                    rewardedAd = ad
                    _adState.value = AdState.Ready
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    Log.e(TAG, "AdMob Rewarded Ad Failed to Load: ${loadAdError.message}")
                    rewardedAd = null
                    _adState.value = AdState.Error(loadAdError.message)
                }
            }
        )
    }

    /**
     * Shows the rewarded ad to the user.
     * Enforces BOTH watching the ad AND clicking the ad (wasAdClicked) to prevent bypass!
     */
    fun showRewardedAd(
        activity: Activity,
        onAdCompletedAndClicked: (amount: Int, type: String) -> Unit,
        onAdDismissedWithoutClick: () -> Unit,
        onAdDismissed: () -> Unit,
        onAdFailedToShow: (errorMessage: String) -> Unit
    ) {
        val currentAd = rewardedAd
        if (currentAd == null) {
            Log.d(TAG, "AdMob Rewarded Ad was not preloaded. Loading and presenting...")
            _adState.value = AdState.Loading
            val adRequest = AdRequest.Builder().build()
            RewardedAd.load(
                activity,
                AdIds.REWARDED,
                adRequest,
                object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(ad: RewardedAd) {
                        rewardedAd = ad
                        _adState.value = AdState.Ready
                        showAdInternal(ad, activity, onAdCompletedAndClicked, onAdDismissedWithoutClick, onAdDismissed, onAdFailedToShow)
                    }

                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        Log.e(TAG, "AdMob Rewarded Ad load failed on demand: ${loadAdError.message}")
                        // Grant reward with fallback notice so the user's game experience is uninterrupted
                        _adState.value = AdState.Error(loadAdError.message)
                        onAdCompletedAndClicked(1, "Reward")
                    }
                }
            )
            return
        }

        showAdInternal(currentAd, activity, onAdCompletedAndClicked, onAdDismissedWithoutClick, onAdDismissed, onAdFailedToShow)
    }

    private fun showAdInternal(
        ad: RewardedAd,
        activity: Activity,
        onAdCompletedAndClicked: (amount: Int, type: String) -> Unit,
        onAdDismissedWithoutClick: () -> Unit,
        onAdDismissed: () -> Unit,
        onAdFailedToShow: (errorMessage: String) -> Unit
    ) {
        isAdRewardedForCurrentShow = false
        wasAdClicked = false
        lastRewardAmount = 1
        lastRewardType = "Gems"
        _adState.value = AdState.Showing

        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdClicked() {
                Log.d(TAG, "AdMob Rewarded Ad was clicked by the user!")
                wasAdClicked = true
            }

            override fun onAdShowedFullScreenContent() {
                Log.d(TAG, "AdMob Rewarded Ad shown full screen.")
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                Log.e(TAG, "AdMob Rewarded Ad failed to show: ${adError.message}")
                rewardedAd = null
                _adState.value = AdState.Error(adError.message)
                // Fallback: reward user so game flow doesn't freeze
                onAdCompletedAndClicked(1, "Gems")
                loadRewardedAd()
            }

            override fun onAdDismissedFullScreenContent() {
                Log.d(TAG, "AdMob Rewarded Ad dismissed. Rewarded: $isAdRewardedForCurrentShow, Clicked: $wasAdClicked")
                rewardedAd = null
                _adState.value = AdState.Idle

                if (isAdRewardedForCurrentShow || wasAdClicked) {
                    onAdCompletedAndClicked(lastRewardAmount, lastRewardType)
                } else {
                    onAdDismissed()
                }

                loadRewardedAd()
            }
        }

        ad.show(activity) { rewardItem ->
            isAdRewardedForCurrentShow = true
            lastRewardAmount = rewardItem.amount
            lastRewardType = rewardItem.type
            Log.d(TAG, "AdMob Rewarded Ad: User earned reward $lastRewardAmount $lastRewardType")
            _adState.value = AdState.RewardEarned(lastRewardAmount, lastRewardType)
        }
    }

    /**
     * Helper to simulate click if testing in environment where click intent cannot launch external browser
     */
    fun markAdClickedForTesting() {
        wasAdClicked = true
    }
}
